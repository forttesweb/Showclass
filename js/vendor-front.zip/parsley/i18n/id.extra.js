// Validation errors messages for Parsley
import Parsley from '../parsley';

Parsley.addMessages('id', {
  dateiso: "Harus tanggal yang valid (YYYY-MM-DD)."
});
